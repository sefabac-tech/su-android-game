package com.example.su

import android.app.Activity
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlin.math.sin
import kotlin.math.cos
import kotlin.math.abs
import kotlin.random.Random

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        window.navigationBarColor = Color.BLACK
        setContentView(SurfView(this))
    }
}

private data class Stage(
    val name: String, val sky: Int, val water: Int, val foam: Int,
    val wave: Float, val speed: Float, val obstacleRate: Float, val board: Int, val effect: Int
)

private val stages = listOf(
    Stage("1 · LAGÜN", 0xFF8DE0F2.toInt(), 0xFF20B7C9.toInt(), 0xFFD7FFFF.toInt(), 22f, 1.0f, 0.004f, 0xFFFFD166.toInt(), 0),
    Stage("2 · MERCAN KOYU", 0xFFFFC5A1.toInt(), 0xFF168AAD.toInt(), 0xFFE9FFF8.toInt(), 34f, 1.25f, 0.007f, 0xFFFF6B6B.toInt(), 1),
    Stage("3 · TURKUAZ GEÇİT", 0xFF9BF6FF.toInt(), 0xFF0077B6.toInt(), 0xFFFFFFFF.toInt(), 47f, 1.55f, 0.010f, 0xFFB8F2E6.toInt(), 2),
    Stage("4 · FIRTINA", 0xFF8D99AE.toInt(), 0xFF264653.toInt(), 0xFFE8F1F2.toInt(), 61f, 1.9f, 0.014f, 0xFF9B5DE5.toInt(), 3),
    Stage("5 · NEON DALGA", 0xFF241046.toInt(), 0xFF3A0CA3.toInt(), 0xFF80FFDB.toInt(), 77f, 2.3f, 0.018f, 0xFFF15BB5.toInt(), 4),
    Stage("6 · DEV DALGA", 0xFF090E28.toInt(), 0xFF102A43.toInt(), 0xFFFF4D6D.toInt(), 98f, 2.85f, 0.024f, 0xFFFFC857.toInt(), 5)
)

private class SurfView(context: android.content.Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var stage = 0
    private var started = false
    private var finished = false
    private var playerX = 0.5f
    private var tick = 0f
    private var score = 0f
    private var lives = 3
    private var invuln = 0f
    private var lastTime = System.nanoTime()
    private val obstacles = mutableListOf<Obstacle>()
    private var message = ""
    private var messageTime = 0f
    private data class Obstacle(var x: Float, var y: Float, var size: Float, var kind: Int)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val dt = ((System.nanoTime() - lastTime) / 1_000_000_000f).coerceIn(0f, 0.04f)
        lastTime = System.nanoTime()
        tick += dt
        val s = stages[stage]
        canvas.drawColor(s.sky)
        drawSun(canvas, s)
        drawWater(canvas, s)
        if (started && !finished) updateGame(dt, s)
        drawObstacles(canvas, s)
        drawBoard(canvas, s)
        drawHud(canvas, s)
        if (!started) drawOverlay(canvas, "su", "SÖRFÜ BAŞLAT", "Ekrana dokun ve dalgaları aş")
        else if (finished) drawOverlay(canvas, if (stage == 5) "EFSANE SÖRFÇÜ!" else "BÖLÜM TAMAMLANDI", if (stage == 5) "TEKRAR OYNA" else "SONRAKİ BÖLÜM", "Puan: ${score.toInt()}   ·   Dokun")
        else if (lives <= 0) drawOverlay(canvas, "DALGA KAZANDI", "TEKRAR DENE", "Puan: ${score.toInt()}   ·   Dokun")
        if (messageTime > 0f) { messageTime -= dt; centered(canvas, message, width/2f, height*0.25f, 28f, Color.WHITE, true) }
        postInvalidateOnAnimation()
    }

    private fun drawSun(c: Canvas, s: Stage) {
        p.color = if (stage == 4) 0xFFFE53BB.toInt() else if (stage == 5) 0xFFFF4D6D.toInt() else 0xFFFFF1A8.toInt()
        p.alpha = 220
        c.drawCircle(width*0.82f, height*0.19f, height*0.07f, p); p.alpha = 255
    }

    private fun drawWater(c: Canvas, s: Stage) {
        p.color = s.water; c.drawRect(0f, height*0.32f, width.toFloat(), height.toFloat(), p)
        for (row in 0..7) {
            val y = height*(0.38f + row*0.095f)
            val amp = s.wave*(0.3f + row*0.15f)
            val path = Path(); path.moveTo(0f, y)
            for (x in 0..width step 12) path.lineTo(x.toFloat(), y + sin(x*0.018f + tick*s.speed*2f + row)*amp)
            p.color = s.foam; p.alpha = if (stage >= 4) 130 else 95; p.strokeWidth = if (stage == 5) 3.5f else 2f; p.style = Paint.Style.STROKE
            c.drawPath(path, p); p.style = Paint.Style.FILL; p.alpha = 255
        }
        if (stage >= 3) {
            p.color = if (stage == 4) 0xFF80FFDB.toInt() else 0xFFFF4D6D.toInt(); p.alpha = 60
            for (i in 0..5) c.drawCircle(((i*193 + tick*120*s.speed) % (width+100)).toFloat(), height*(0.45f+i*0.08f), 3f+stage, p)
            p.alpha = 255
        }
    }

    private fun updateGame(dt: Float, s: Stage) {
        if (lives <= 0) return
        score += dt * 10 * s.speed
        invuln = (invuln-dt).coerceAtLeast(0f)
        if (Random.nextFloat() < s.obstacleRate * (dt*60f)) obstacles.add(Obstacle(Random.nextFloat()*0.86f+0.07f, -0.05f, Random.nextFloat()*0.018f+0.012f, Random.nextInt(3)))
        val iterator = obstacles.iterator()
        while (iterator.hasNext()) {
            val o = iterator.next(); o.y += dt * (0.26f*s.speed)
            if (o.y > 1.1f) { iterator.remove(); score += 15f }
            else if (invuln <= 0f && abs(o.x-playerX) < o.size+0.035f && abs(o.y-0.76f) < 0.055f) {
                iterator.remove(); lives--; invuln = 1.2f; message = "SPLASH!"; messageTime = 0.7f
            }
        }
        if (score >= (stage+1)*190f) {
            if (stage < 5) { stage++; obstacles.clear(); score += 20f; message = "${stage+1}. BÖLÜM: ${stages[stage].name}"; messageTime = 1.6f; lives = (lives+1).coerceAtMost(3) }
            else finished = true
        }
    }

    private fun drawObstacles(c: Canvas, s: Stage) {
        for (o in obstacles) {
            val x = o.x*width; val y = o.y*height; val r = o.size*width
            p.color = when(o.kind) { 0 -> 0xFF263238.toInt(); 1 -> 0xFFEF476F.toInt(); else -> 0xFFFFD166.toInt() }
            c.drawCircle(x, y, r, p)
            p.color = s.foam; p.style = Paint.Style.STROKE; p.strokeWidth = 2.5f; c.drawCircle(x-r*0.25f, y-r*0.25f, r*0.55f, p); p.style = Paint.Style.FILL
        }
    }

    private fun drawBoard(c: Canvas, s: Stage) {
        val x = playerX*width; val y = height*0.76f
        if (invuln > 0 && (tick*12).toInt()%2 == 0) return
        p.color = Color.argb(90, 0, 0, 0); c.drawOval(x-width*0.055f, y+height*0.018f, x+width*0.055f, y+height*0.04f, p)
        c.save(); c.rotate(sin(tick*2.2f)*4f, x, y)
        p.color = s.board
        val board = Path().apply { moveTo(x-width*0.065f,y); quadTo(x-width*0.04f,y-height*0.025f,x,y-height*0.018f); quadTo(x+width*0.06f,y-height*0.025f,x+width*0.065f,y); quadTo(x+width*0.04f,y+height*0.025f,x,y+height*0.019f); quadTo(x-width*0.045f,y+height*0.025f,x-width*0.065f,y); close() }
        c.drawPath(board,p)
        p.color = Color.WHITE; p.strokeWidth = 3f; c.drawLine(x, y-height*0.013f, x, y+height*0.013f,p)
        p.color = if(stage>=4) 0xFF80FFDB.toInt() else 0xFF263238.toInt()
        c.drawCircle(x,y-height*0.045f,height*0.019f,p)
        p.strokeWidth = height*0.012f; p.strokeCap = Paint.Cap.ROUND
        c.drawLine(x,y-height*0.027f,x-width*0.018f,y+height*0.002f,p); c.drawLine(x,y-height*0.027f,x+width*0.02f,y-height*0.005f,p)
        c.drawLine(x,y-height*0.002f,x-width*0.015f,y+height*0.018f,p); c.drawLine(x,y-height*0.002f,x+width*0.02f,y+height*0.016f,p)
        c.restore()
    }

    private fun drawHud(c: Canvas, s: Stage) {
        p.color = Color.argb(120,0,0,0); c.drawRoundRect(18f,18f, width*0.52f, height*0.13f,18f,18f,p)
        text(c, s.name, 34f, 53f, 18f, Color.WHITE, true)
        text(c, "PUAN ${score.toInt()}   ♥ $lives", 34f, 82f, 16f, Color.WHITE, false)
        text(c, "SOLA / SAĞA KAYDIR", width-250f, 42f, 14f, Color.WHITE, true)
    }

    private fun drawOverlay(c: Canvas, title: String, button: String, sub: String) {
        p.color = Color.argb(155, 2, 12, 27); c.drawRect(0f,0f,width.toFloat(),height.toFloat(),p)
        centered(c,title,width/2f,height*0.36f, if(title=="su") 72f else 42f,Color.WHITE,true)
        centered(c,sub,width/2f,height*0.47f,20f,0xFFBDE0FE.toInt(),false)
        p.color = 0xFF00B4D8.toInt(); c.drawRoundRect(width*0.34f,height*0.56f,width*0.66f,height*0.68f,24f,24f,p)
        centered(c,button,width/2f,height*0.635f,22f,Color.WHITE,true)
    }

    private fun text(c: Canvas, str: String, x: Float, y: Float, size: Float, color: Int, bold: Boolean) {
        p.color=color; p.textSize=size; p.typeface=if(bold) android.graphics.Typeface.create("sans-serif",android.graphics.Typeface.BOLD) else android.graphics.Typeface.create("sans-serif",android.graphics.Typeface.NORMAL); c.drawText(str,x,y,p)
    }
    private fun centered(c: Canvas, str: String, x: Float, y: Float, size: Float, color: Int, bold: Boolean) {
        p.textSize=size; p.typeface=if(bold) android.graphics.Typeface.create("sans-serif",1) else android.graphics.Typeface.create("sans-serif",0); p.color=color; c.drawText(str,x-p.measureText(str)/2f,y,p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when(e.action) {
            MotionEvent.ACTION_DOWN -> {
                if (!started || finished || lives <= 0) {
                    if (finished || lives <= 0) { stage=0; score=0f; lives=3; obstacles.clear(); finished=false; playerX=0.5f }
                    started=true; return true
                }
                movePlayer(e.x); return true
            }
            MotionEvent.ACTION_MOVE -> { if(started && !finished && lives>0) movePlayer(e.x); return true }
        }
        return true
    }
    private fun movePlayer(x: Float) { playerX=(x/width).coerceIn(0.07f,0.93f) }
}
