# su — Android sörf oyunu

Kotlin ile yazılmış, internet veya harici oyun motoru gerektirmeyen basit bir Android oyunu prototipi. Oyun yatay ekran için tasarlanmıştır.

## Oynanış
- Ekrana dokunarak oyunu başlatın.
- Parmağınızı sağa/sola sürükleyerek sörfçüyü yönlendirin.
- Engellerden kaçın, puan toplayın ve altı bölümde ilerleyin.
- Bölümler ilerledikçe dalga boyu, oyun hızı ve engel sıklığı artar; renk paleti ve sörf tahtası değişir.

## APK oluşturma
1. Android Studio'da `su_android` klasörünü açın.
2. Gradle senkronizasyonunun bitmesini bekleyin (Android SDK 35 ve internet bağlantısı gerekebilir).
3. **Build > Build APK(s)** seçin.
4. APK genellikle `app/build/outputs/apk/debug/app-debug.apk` konumunda oluşur.

Bu teslim kaynak kodudur; burada Android SDK ile derlenmiş APK sunulmuyor. Yayın öncesinde farklı ekran boyutlarında test edilmesi, ses/müzik ve gerçek cihaz performansının iyileştirilmesi önerilir.
